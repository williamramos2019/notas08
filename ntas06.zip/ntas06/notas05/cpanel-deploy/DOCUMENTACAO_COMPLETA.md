# 📚 DOCUMENTAÇÃO COMPLETA - Sistema Controle de Notas Fiscais

## 🏗️ Arquitetura do Sistema

### **Frontend (React + TypeScript)**
- **Framework**: React 18 com TypeScript
- **Build**: Vite (otimizado para produção)
- **Styling**: Tailwind CSS + shadcn/ui
- **Roteamento**: Wouter (React Router leve)
- **Estado**: TanStack Query para cache de dados
- **Formulários**: React Hook Form + Zod validation

### **Backend (PHP + SQLite)**
- **Linguagem**: PHP 8.0+
- **Banco**: SQLite (arquivo local)
- **API**: REST endpoints em PHP puro
- **CORS**: Configurado para frontend
- **Rotas**: .htaccess com mod_rewrite

---

## 📁 Estrutura Detalhada dos Arquivos

```
cpanel-deploy/
├── 📁 public_html/                    # PASTA PRINCIPAL PARA UPLOAD
│   ├── 📄 index.html                  # Aplicação React (entrada principal)
│   ├── 📄 .htaccess                   # Configuração Apache (rotas React)
│   │
│   ├── 📁 assets/                     # Assets compilados do Vite
│   │   ├── 📄 index-BgIqMF3K.js      # JavaScript da aplicação (474KB)
│   │   └── 📄 index-DziWY15y.css     # Estilos CSS (60KB)
│   │
│   └── 📁 api/                        # Backend PHP
│       ├── 📄 config.php              # Configuração SQLite + CORS
│       ├── 📄 suppliers.php           # API: Fornecedores (CRUD)
│       ├── 📄 invoices.php            # API: Notas Fiscais (CRUD)
│       ├── 📄 dashboard.php           # API: Métricas do Dashboard
│       ├── 📄 init_database.php       # Script de inicialização
│       └── 📄 .htaccess               # URLs amigáveis da API
│
├── 📄 INSTRUCOES_INSTALACAO.md        # Guia de instalação
├── 📄 README.txt                      # Instalação rápida
├── 📄 VERSAO.txt                      # Informações da versão
└── 📄 DOCUMENTACAO_COMPLETA.md        # Este arquivo
```

---

## 🚀 INSTALAÇÃO PASSO A PASSO

### **1. Preparação do cPanel (Hostgator)**

#### **1.1 Acesso ao cPanel**
1. Faça login no cPanel da Hostgator
2. Localize **"Gerenciador de Arquivos"**
3. Navegue até a pasta **`public_html`**

#### **1.2 Backup (Se necessário)**
```bash
# Se já existir conteúdo, faça backup:
1. Selecione todos os arquivos existentes
2. Clique em "Compactar" → "Zip"
3. Nomeie como "backup_YYYY-MM-DD.zip"
4. Faça download do backup
```

#### **1.3 Limpeza**
- **Opção A**: Delete todo conteúdo de `public_html` (site novo)
- **Opção B**: Crie subpasta `sistema` em `public_html` (site existente)

### **2. Upload dos Arquivos**

#### **2.1 Upload Completo**
1. Selecione **todos os arquivos** da pasta `cpanel-deploy/public_html/`
2. **Arraste e solte** ou use "Selecionar Arquivo"
3. Faça upload para:
   - **Site novo**: Diretamente em `public_html/`
   - **Subpasta**: Em `public_html/sistema/`

#### **2.2 Verificação da Estrutura**
Após upload, confirme esta estrutura:
```
public_html/
├── index.html          ✅ (página principal)
├── .htaccess           ✅ (configuração Apache)
├── assets/             ✅ (pasta com JS/CSS)
│   ├── index-xxx.js    ✅
│   └── index-xxx.css   ✅
└── api/                ✅ (pasta da API)
    ├── config.php      ✅
    ├── suppliers.php   ✅
    ├── invoices.php    ✅
    ├── dashboard.php   ✅
    ├── init_database.php ✅
    └── .htaccess       ✅
```

### **3. Configuração de Permissões**

#### **3.1 Permissões dos Arquivos PHP**
```bash
Arquivo                 Permissão    Descrição
config.php             644          Leitura/escrita proprietário
suppliers.php          644          API fornecedores
invoices.php           644          API notas fiscais
dashboard.php          644          API dashboard
init_database.php      644          Inicializador (deletar depois)
```

#### **3.2 Permissões das Pastas**
```bash
Pasta                  Permissão    Descrição
public_html/           755          Pasta principal
api/                   755          API (precisa escrever SQLite)
assets/                755          Assets estáticos
```

#### **3.3 Como Alterar Permissões**
1. Clique com botão direito no arquivo/pasta
2. Selecione **"Permissões"**
3. Configure os números indicados acima
4. Clique **"Alterar Permissões"**

### **4. Inicialização do Banco de Dados**

#### **4.1 Executar Script de Inicialização**
1. **Acesse**: `https://seudominio.com/api/init_database.php`
2. O script irá:
   - ✅ Criar arquivo `database.sqlite`
   - ✅ Criar tabelas: `suppliers`, `invoices`, `alerts`
   - ✅ Inserir dados de exemplo
   - ✅ Verificar configuração

#### **4.2 Dados de Exemplo Criados**
```sql
-- FORNECEDORES
Empresa ABC Ltda        (CNPJ: 12.345.678/0001-90, Tipo: Serviço)
Locadora XYZ           (CNPJ: 98.765.432/0001-10, Tipo: Locação)
Fornecedor 123         (CNPJ: 11.222.333/0001-44, Tipo: Produto)

-- NOTAS FISCAIS
NFE-2024-001           (Contrato, R$ 5.000,00)
NFE-2024-002           (Locação, R$ 3.500,00, Vence em 3 dias)
NFE-2024-003           (Avulsa, R$ 1.200,00, Vencida há 2 dias)
```

#### **4.3 ⚠️ IMPORTANTE: Deletar Script**
```bash
Após inicialização bem-sucedida:
1. Delete o arquivo "init_database.php"
2. Motivo: Segurança (evita reinicialização acidental)
3. Local: public_html/api/init_database.php
```

### **5. Teste e Verificação**

#### **5.1 Teste da Aplicação**
1. **Acesse**: `https://seudominio.com`
2. **Verifique**:
   - ✅ Página carrega sem erros
   - ✅ Menu lateral funciona
   - ✅ Dashboard mostra métricas
   - ✅ Botões "Nova Nota" e "Novo Fornecedor" abrem modais

#### **5.2 Teste das APIs**
```bash
# Teste direto das APIs:
GET https://seudominio.com/api/suppliers.php      # Lista fornecedores
GET https://seudominio.com/api/invoices.php       # Lista notas fiscais
GET https://seudominio.com/api/dashboard.php      # Métricas dashboard
```

---

## 💾 BANCO DE DADOS SQLite

### **Localização do Banco**
```bash
Arquivo: public_html/api/database.sqlite
Tipo: SQLite (banco local em arquivo)
Criado: Automaticamente pelo init_database.php
Tamanho: ~50KB (com dados exemplo)
```

### **Estrutura das Tabelas**

#### **Tabela: suppliers (Fornecedores)**
```sql
CREATE TABLE suppliers (
    id TEXT PRIMARY KEY,              -- UUID único
    name TEXT NOT NULL,               -- Nome da empresa
    cnpj TEXT NOT NULL UNIQUE,        -- CNPJ (apenas números)
    supplier_type TEXT NOT NULL,      -- 'rental'|'service'|'product'
    contract_balance DECIMAL(15,2),   -- Saldo do contrato
    monitored BOOLEAN DEFAULT 0,      -- Fornecedor monitorado
    created_at TIMESTAMP,             -- Data de criação
    updated_at TIMESTAMP              -- Última atualização
);
```

#### **Tabela: invoices (Notas Fiscais)**
```sql
CREATE TABLE invoices (
    id TEXT PRIMARY KEY,              -- UUID único
    invoice_number TEXT NOT NULL UNIQUE, -- Número da nota
    supplier_id TEXT NOT NULL,        -- FK para suppliers
    issue_date TIMESTAMP NOT NULL,    -- Data de emissão
    due_date TIMESTAMP NOT NULL,      -- Data de vencimento
    value DECIMAL(15,2) NOT NULL,     -- Valor da nota
    invoice_type TEXT NOT NULL,       -- 'contract'|'adhoc'|'rental'
    
    -- Status checkboxes
    posted BOOLEAN DEFAULT 0,         -- Nota lançada
    attachment_uploaded BOOLEAN DEFAULT 0, -- Boleto anexo
    regularized BOOLEAN DEFAULT 0,    -- Regularização
    measurement_approved BOOLEAN DEFAULT 0, -- Aprovação medição
    measured BOOLEAN DEFAULT 0,       -- Medido
    
    contract_balance DECIMAL(15,2),   -- Saldo do contrato
    priority_alert BOOLEAN DEFAULT 0, -- Alerta prioritário
    created_at TIMESTAMP,             -- Data de criação
    updated_at TIMESTAMP,             -- Última atualização
    
    FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
);
```

#### **Tabela: alerts (Alertas)**
```sql
CREATE TABLE alerts (
    id TEXT PRIMARY KEY,              -- UUID único
    invoice_id TEXT NOT NULL,         -- FK para invoices
    days_remaining INTEGER NOT NULL,  -- Dias até vencimento
    alert_sent BOOLEAN DEFAULT 0,     -- Alerta já enviado
    created_at TIMESTAMP,             -- Data de criação
    
    FOREIGN KEY (invoice_id) REFERENCES invoices (id)
);
```

### **Backup e Restauração**

#### **Backup Manual**
```bash
1. Acesse: cPanel → Gerenciador de Arquivos
2. Navegue: public_html/api/
3. Selecione: database.sqlite
4. Clique: "Download"
5. Salve em local seguro
```

#### **Restauração**
```bash
1. Upload do arquivo database.sqlite
2. Substitua o arquivo existente
3. Mantenha permissões 644
4. Teste o sistema
```

#### **Backup Automático (Recomendado)**
```bash
Configurar no cPanel:
1. Vá em "Backups"
2. Configure backup diário/semanal
3. Inclua arquivos do site
4. Download periódico dos backups
```

---

## 🔧 CONFIGURAÇÕES AVANÇADAS

### **URLs e Rotas**

#### **Estrutura de URLs**
```bash
# Frontend (React Router)
https://seudominio.com/           # Dashboard
https://seudominio.com/invoices   # Notas Fiscais
https://seudominio.com/suppliers  # Fornecedores
https://seudominio.com/reports    # Relatórios

# Backend (API REST)
https://seudominio.com/api/suppliers.php    # CRUD Fornecedores
https://seudominio.com/api/invoices.php     # CRUD Notas Fiscais
https://seudominio.com/api/dashboard.php    # Métricas
```

#### **Configuração .htaccess Principal**
```apache
# public_html/.htaccess
RewriteEngine On

# Redirecionar rotas React para index.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} !^/api/
RewriteRule . /index.html [L]

# Cache assets estáticos (1 ano)
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
</IfModule>
```

#### **Configuração .htaccess API**
```apache
# public_html/api/.htaccess
RewriteEngine On

# URLs amigáveis da API
RewriteRule ^suppliers/?$ suppliers.php [L]
RewriteRule ^suppliers/([^/]+)/?$ suppliers.php [L]
RewriteRule ^invoices/?$ invoices.php [L] 
RewriteRule ^invoices/([^/]+)/?$ invoices.php [L]
RewriteRule ^dashboard/metrics/?$ dashboard.php [L]

# CORS Headers
Header always set Access-Control-Allow-Origin "*"
Header always set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
Header always set Access-Control-Allow-Headers "Content-Type, Authorization"
```

### **Personalização de Domínio**

#### **Instalação em Subpasta**
```bash
Para instalar em: https://seudominio.com/sistema/

1. Crie pasta: public_html/sistema/
2. Upload arquivos dentro de /sistema/
3. Acesse: seudominio.com/sistema/
4. API ficará: seudominio.com/sistema/api/
```

#### **Domínio Próprio**
```bash
Para usar domínio próprio:

1. Configure DNS apontando para Hostgator
2. Adicione domínio no cPanel
3. Upload para pasta do domínio
4. Configure SSL/HTTPS
```

### **SSL e HTTPS**

#### **Certificado SSL Gratuito**
```bash
No cPanel:
1. Vá em "SSL/TLS"
2. Selecione "Let's Encrypt"
3. Ative para seu domínio
4. Force HTTPS (redirecionamento)
```

#### **Forçar HTTPS (.htaccess)**
```apache
# Adicionar ao início do .htaccess
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## 🔍 SOLUÇÃO DE PROBLEMAS

### **Problemas Comuns**

#### **❌ Erro: "Página não encontrada" (404)**
```bash
Causa: Arquivo .htaccess não funcionando
Solução:
1. Verifique se mod_rewrite está ativo
2. Confirme upload do .htaccess
3. Teste permissões (644)
4. Contate suporte se persistir
```

#### **❌ Erro: "Internal Server Error" (500)**
```bash
Causa: Erro no PHP ou permissões
Solução:
1. Verifique logs: cPanel → "Logs de Erro"
2. Confirme PHP 7.4+ ativo
3. Verifique permissões da pasta api/ (755)
4. Teste SQLite habilitado
```

#### **❌ Erro: "Falha na conexão com API"**
```bash
Causa: API não responde
Solução:
1. Teste direto: seudominio.com/api/suppliers.php
2. Verifique permissões arquivos PHP (644)
3. Confirme SQLite instalado
4. Execute novamente init_database.php
```

#### **❌ Erro: "Banco de dados não existe"**
```bash
Causa: SQLite não criado
Solução:
1. Execute: seudominio.com/api/init_database.php
2. Verifique criação: api/database.sqlite
3. Confirme permissões pasta api/ (755)
4. Teste escrita na pasta
```

### **Logs e Depuração**

#### **Logs do PHP**
```bash
Local: cPanel → "Logs de Erro"
Busque por:
- "Permission denied"
- "SQLite"
- "Parse error"
- "Fatal error"
```

#### **Console do Navegador**
```bash
Abrir: F12 → Console
Busque por:
- Erros de carregamento (404, 500)
- Erros de CORS
- Falhas de API
- Problemas de JavaScript
```

#### **Teste Direto da API**
```bash
# Teste individual das APIs
curl https://seudominio.com/api/suppliers.php
curl https://seudominio.com/api/invoices.php
curl https://seudominio.com/api/dashboard.php
```

### **Verificação de Requisitos**

#### **PHP e Extensões**
```bash
Verificar no cPanel:
1. "Seletor de Versão PHP" → PHP 7.4+
2. "Extensões PHP" → SQLite3 ativado
3. "Módulos Apache" → mod_rewrite ativo
```

#### **Teste de Escrita**
```bash
Para testar se PHP pode escrever:
1. Crie arquivo: test_write.php
2. Código: <?php file_put_contents('test.txt', 'ok'); echo 'OK'; ?>
3. Execute e verifique criação de test.txt
4. Delete arquivos de teste
```

---

## 📊 MONITORAMENTO E MANUTENÇÃO

### **Backup Regular**

#### **Frequência Recomendada**
```bash
Diário:   database.sqlite (dados críticos)
Semanal:  pasta api/ completa
Mensal:   backup completo do site
```

#### **Procedimento**
```bash
1. Download database.sqlite
2. Compactar pasta api/
3. Salvar em local seguro (nuvem)
4. Testar restauração periodicamente
```

### **Atualizações**

#### **Atualizações do Sistema**
```bash
Quando disponíveis:
1. Backup completo atual
2. Upload novos arquivos PHP
3. Manter database.sqlite existente
4. Testar funcionalidades
```

#### **Versioning**
```bash
Controle de versão simples:
- backup_v1.0_2025-01-15.zip
- backup_v1.1_2025-02-01.zip
```

### **Performance**

#### **Otimizações**
```bash
1. Cache ativo (.htaccess)
2. Compressão GZIP habilitada
3. Assets minificados (Vite)
4. SQLite otimizado
```

#### **Monitoramento**
```bash
Verificar:
- Tamanho database.sqlite
- Logs de erro
- Tempo de resposta
- Uso de recursos
```

---

## 🎯 PRÓXIMOS PASSOS

### **Após Instalação**
1. ✅ **Delete** `init_database.php`
2. ✅ **Cadastre** seus fornecedores reais
3. ✅ **Configure** backup automático
4. ✅ **Teste** todas as funcionalidades

### **Uso Diário**
1. 📋 **Cadastrar** novas notas fiscais
2. 📊 **Monitorar** dashboard de alertas
3. 🔍 **Filtrar** por vencimento/status
4. 💰 **Acompanhar** saldos de contrato

### **Manutenção Semanal**
1. 💾 **Backup** do banco de dados
2. 📈 **Verificar** relatórios
3. 🧹 **Limpar** notas antigas (se necessário)
4. 🔧 **Verificar** logs de erro

---

## 📞 SUPORTE TÉCNICO

### **Autodiagnóstico**
1. ✅ PHP 7.4+ ativo?
2. ✅ SQLite habilitado?
3. ✅ mod_rewrite funcionando?
4. ✅ Permissões corretas?
5. ✅ Arquivos todos uploadados?

### **Recursos de Ajuda**
- 📖 `INSTRUCOES_INSTALACAO.md` - Guia básico
- 📄 `README.txt` - Instalação rápida
- 📋 `VERSAO.txt` - Informações técnicas
- 📚 `DOCUMENTACAO_COMPLETA.md` - Este arquivo

### **Contato Hostgator**
Se problemas persistirem, contate o suporte com estas informações:
- Sistema: Controle de Notas Fiscais
- Tecnologia: PHP + SQLite + React
- Erro específico: (descrever detalhadamente)
- Logs de erro: (copiar mensagens exatas)

---

**🎉 Sistema instalado e funcionando perfeitamente!**
**📧 Documentação criada por: Sistema Controle de Notas Fiscais v1.0**