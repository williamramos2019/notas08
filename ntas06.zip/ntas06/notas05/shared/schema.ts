import { sql } from "drizzle-orm";
import { sqliteTable, text, real, integer } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const suppliers = sqliteTable("suppliers", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(6))))`),
  name: text("name").notNull(),
  cnpj: text("cnpj").notNull().unique(),
  supplierType: text("supplier_type").notNull(), // 'rental', 'service', 'product'
  contractBalance: real("contract_balance").default(0),
  monitored: integer("monitored", { mode: "boolean" }).default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`),
  updatedAt: integer("updated_at", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

export const invoices = sqliteTable("invoices", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(6))))`),
  invoiceNumber: text("invoice_number").notNull(),
  nfeKey: text("nfe_key").unique(), // Chave da NFe para validação de duplicidade
  supplierId: text("supplier_id").notNull().references(() => suppliers.id),
  issueDate: integer("issue_date", { mode: "timestamp" }).notNull(),
  dueDate: integer("due_date", { mode: "timestamp" }).notNull(),
  value: real("value").notNull(),
  invoiceType: text("invoice_type").notNull(), // 'contract', 'adhoc', 'rental'
  
  // Status checkboxes
  posted: integer("posted", { mode: "boolean" }).default(false),
  attachmentUploaded: integer("attachment_uploaded", { mode: "boolean" }).default(false),
  regularized: integer("regularized", { mode: "boolean" }).default(false),
  measurementApproved: integer("measurement_approved", { mode: "boolean" }).default(false),
  measured: integer("measured", { mode: "boolean" }).default(false),
  
  contractBalance: real("contract_balance"),
  priorityAlert: integer("priority_alert", { mode: "boolean" }).default(false),
  
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`),
  updatedAt: integer("updated_at", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

export const alerts = sqliteTable("alerts", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(6))))`),
  invoiceId: text("invoice_id").notNull().references(() => invoices.id),
  daysRemaining: integer("days_remaining").notNull(),
  alertSent: integer("alert_sent", { mode: "boolean" }).default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

// Tabela de logs de auditoria
export const auditLogs = sqliteTable("audit_logs", {
  id: text("id").primaryKey().default(sql`(lower(hex(randomblob(4))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(2))) || '-' || lower(hex(randomblob(6))))`),
  entityType: text("entity_type").notNull(), // 'invoice', 'supplier'
  entityId: text("entity_id").notNull(),
  action: text("action").notNull(), // 'created', 'updated', 'deleted'
  oldValues: text("old_values"), // JSON das informações anteriores
  newValues: text("new_values"), // JSON das informações novas
  changeDescription: text("change_description"), // Descrição legivel
  source: text("source").default('manual'), // 'xml_upload', 'manual', 'api'
  createdAt: integer("created_at", { mode: "timestamp" }).default(sql`(unixepoch())`),
});

// Relations
export const suppliersRelations = relations(suppliers, ({ many }) => ({
  invoices: many(invoices),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  supplier: one(suppliers, {
    fields: [invoices.supplierId],
    references: [suppliers.id],
  }),
  alerts: many(alerts),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  invoice: one(invoices, {
    fields: [alerts.invoiceId],
    references: [invoices.id],
  }),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  // Relations podem ser adicionadas conforme necessário
}));

// Insert schemas
export const insertSupplierSchema = createInsertSchema(suppliers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type Supplier = typeof suppliers.$inferSelect;
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;

// Combined types for API responses
export type InvoiceWithSupplier = Invoice & {
  supplier: Supplier;
};

export type SupplierWithInvoices = Supplier & {
  invoices: Invoice[];
};
