import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { InvoiceWithSupplier, Supplier } from "@shared/schema";
import type { InvoiceFormData } from "@/lib/types";

const invoiceFormSchema = z.object({
  invoiceNumber: z.string().min(1, "Número da nota é obrigatório"),
  supplierId: z.string().min(1, "Fornecedor é obrigatório"),
  issueDate: z.string().min(1, "Data de emissão é obrigatória"),
  dueDate: z.string().min(1, "Data de vencimento é obrigatória"),
  value: z.string().min(1, "Valor é obrigatório"),
  invoiceType: z.enum(["contract", "adhoc", "rental"], {
    required_error: "Tipo de nota é obrigatório"
  }),
  posted: z.boolean().default(false),
  attachmentUploaded: z.boolean().default(false),
  regularized: z.boolean().default(false),
  measurementApproved: z.boolean().default(false),
  measured: z.boolean().default(false),
  contractBalance: z.string().optional(),
});

interface InvoiceFormModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: InvoiceFormData) => void;
  invoice?: InvoiceWithSupplier;
}

export function InvoiceFormModal({ open, onClose, onSubmit, invoice }: InvoiceFormModalProps) {
  const [supplierSearch, setSupplierSearch] = useState("");
  const [isProcessingXML, setIsProcessingXML] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: suppliers = [] } = useQuery({
    queryKey: ["/api/suppliers", supplierSearch],
    queryFn: () => supplierSearch ? api.searchSuppliers(supplierSearch) : api.getSuppliers(),
    enabled: open,
  });

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      invoiceNumber: "",
      supplierId: "",
      issueDate: "",
      dueDate: "",
      value: "",
      invoiceType: "contract",
      posted: false,
      attachmentUploaded: false,
      regularized: false,
      measurementApproved: false,
      measured: false,
      contractBalance: "",
    },
  });

  useEffect(() => {
    if (invoice) {
      form.reset({
        invoiceNumber: invoice.invoiceNumber,
        supplierId: invoice.supplierId,
        issueDate: new Date(invoice.issueDate).toISOString().split('T')[0],
        dueDate: new Date(invoice.dueDate).toISOString().split('T')[0],
        value: invoice.value.toString(),
        invoiceType: invoice.invoiceType as "contract" | "adhoc" | "rental",
        posted: invoice.posted ?? false,
        attachmentUploaded: invoice.attachmentUploaded ?? false,
        regularized: invoice.regularized ?? false,
        measurementApproved: invoice.measurementApproved ?? false,
        measured: invoice.measured ?? false,
        contractBalance: invoice.contractBalance ? invoice.contractBalance.toString() : "",
      });
    } else {
      form.reset({
        invoiceNumber: "",
        supplierId: "",
        issueDate: "",
        dueDate: "",
        value: "",
        invoiceType: "contract",
        posted: false,
        attachmentUploaded: false,
        regularized: false,
        measurementApproved: false,
        measured: false,
        contractBalance: "",
      });
    }
  }, [invoice, form]);

  const handleSubmit = (data: InvoiceFormData) => {
    onSubmit(data);
    onClose();
  };

  const formatCurrency = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    const amount = parseFloat(numbers) / 100;
    return amount.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });
  };

  const handleXMLUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.xml')) {
      toast({
        title: "Erro",
        description: "Por favor, selecione um arquivo XML válido.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessingXML(true);
    
    try {
      const xmlText = await file.text();
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
      
      // Verificar se é um XML válido
      if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
        throw new Error('XML inválido');
      }

      // Extrair dados da NFe (formato padrão brasileiro)
      const extractXMLData = () => {
        try {
          // Chave da NFe para validação de duplicidade
          const nfeKey = xmlDoc.getElementsByTagName('infNFe')[0]?.getAttribute('Id')?.replace('NFe', '') || '';
          
          // Número da nota
          const nNF = xmlDoc.getElementsByTagName('nNF')[0]?.textContent || '';
          const serie = xmlDoc.getElementsByTagName('serie')[0]?.textContent || '';
          const invoiceNumber = serie && nNF ? `${serie}-${nNF}` : nNF;

          // Fornecedor (emitente)
          const xNome = xmlDoc.getElementsByTagName('xNome')[0]?.textContent || '';
          const cnpj = xmlDoc.getElementsByTagName('CNPJ')[0]?.textContent || '';

          // Datas
          const dhEmi = xmlDoc.getElementsByTagName('dhEmi')[0]?.textContent || 
                        xmlDoc.getElementsByTagName('dEmi')[0]?.textContent || '';
          const dVenc = xmlDoc.getElementsByTagName('dVenc')[0]?.textContent || '';

          // Valor total
          const vNF = xmlDoc.getElementsByTagName('vNF')[0]?.textContent || '0';

          if (!invoiceNumber || !xNome || !cnpj) {
            throw new Error('Dados essenciais não encontrados no XML (número, fornecedor ou CNPJ)');
          }

          return {
            nfeKey,
            invoiceNumber,
            supplierName: xNome,
            supplierCNPJ: cnpj,
            issueDate: dhEmi ? dhEmi.split('T')[0] : '',
            dueDate: dVenc,
            value: parseFloat(vNF).toFixed(2)
          };
        } catch (error) {
          throw new Error(`Erro ao extrair dados do XML: ${error instanceof Error ? error.message : 'Formato inválido'}`);
        }
      };

      const xmlData = extractXMLData();

      if (!xmlData.invoiceNumber) {
        throw new Error('Não foi possível extrair o número da nota fiscal do XML');
      }

      // Verificar se a nota já existe (por chave NFe ou número)
      const existingInvoice = await fetch(`/api/invoices?search=${encodeURIComponent(xmlData.invoiceNumber)}`)
        .then(res => res.json())
        .then(invoices => {
          // Primeiro tentar por chave NFe, depois por número
          return invoices.find((inv: any) => 
            (xmlData.nfeKey && inv.nfeKey === xmlData.nfeKey) || 
            inv.invoiceNumber === xmlData.invoiceNumber
          );
        })
        .catch(() => null);

      if (existingInvoice) {
        // Nota já existe, só preencher o formulário com os dados existentes
        form.setValue('invoiceNumber', existingInvoice.invoiceNumber);
        form.setValue('supplierId', existingInvoice.supplierId);
        form.setValue('issueDate', new Date(existingInvoice.issueDate).toISOString().split('T')[0]);
        form.setValue('dueDate', new Date(existingInvoice.dueDate).toISOString().split('T')[0]);
        form.setValue('value', existingInvoice.value.toString());
        form.setValue('invoiceType', existingInvoice.invoiceType);
        form.setValue('posted', existingInvoice.posted);
        form.setValue('attachmentUploaded', existingInvoice.attachmentUploaded);
        form.setValue('regularized', existingInvoice.regularized);
        form.setValue('measurementApproved', existingInvoice.measurementApproved);
        form.setValue('measured', existingInvoice.measured);
        form.setValue('contractBalance', existingInvoice.contractBalance?.toString() || '');
        
        toast({
          title: "Nota fiscal encontrada",
          description: `Nota ${xmlData.invoiceNumber} já existe. Dados carregados para edição.`,
        });
        return;
      }

      // Nota não existe, preencher formulário para criação
      form.setValue('invoiceNumber', xmlData.invoiceNumber);
      form.setValue('issueDate', xmlData.issueDate);
      form.setValue('dueDate', xmlData.dueDate || xmlData.issueDate);
      form.setValue('value', xmlData.value);

      // Tentar encontrar ou criar fornecedor
      if (xmlData.supplierCNPJ && xmlData.supplierName) {
        const cleanCNPJ = xmlData.supplierCNPJ.replace(/\D/g, '');
        let foundSupplier = suppliers.find(s => 
          s.cnpj.replace(/\D/g, '') === cleanCNPJ
        );
        
        if (foundSupplier) {
          form.setValue('supplierId', foundSupplier.id);
        } else {
          // Criar novo fornecedor automaticamente
          try {
            const formatCNPJ = (cnpj: string) => {
              const clean = cnpj.replace(/\D/g, '');
              return clean.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
            };
            
            const newSupplierData = {
              name: xmlData.supplierName,
              cnpj: formatCNPJ(cleanCNPJ),
              supplierType: 'service' as const,
              monitored: false
            };
            
            const response = await fetch('/api/suppliers', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(newSupplierData),
            });
            
            if (response.ok) {
              const newSupplier = await response.json();
              form.setValue('supplierId', newSupplier.id);
              
              toast({
                title: "Fornecedor criado automaticamente",
                description: `Fornecedor ${xmlData.supplierName} foi registrado no sistema.`,
              });
              
              // Invalidar a query para recarregar os fornecedores
              queryClient.invalidateQueries({ queryKey: ['/api/suppliers'] });
            } else {
              console.error('Erro ao criar fornecedor:', response.statusText);
              toast({
                title: "Aviso",
                description: "Fornecedor não encontrado. Por favor, cadastre-o manualmente.",
                variant: "destructive",
              });
            }
          } catch (error) {
            console.error('Erro ao criar fornecedor:', error);
            toast({
              title: "Aviso",
              description: "Erro ao criar fornecedor automaticamente. Cadastre-o manualmente.",
              variant: "destructive",
            });
          }
        }
      }

      // Criar automaticamente a nota fiscal se não existir
      if (!existingInvoice && xmlData.supplierName) {
        try {
          const supplierId = form.getValues('supplierId');
          if (supplierId) {
            const invoiceData = {
              invoiceNumber: xmlData.invoiceNumber,
              nfeKey: xmlData.nfeKey || null,
              supplierId: supplierId,
              issueDate: new Date(xmlData.issueDate),
              dueDate: new Date(xmlData.dueDate || xmlData.issueDate),
              value: parseFloat(xmlData.value),
              invoiceType: 'contract' as const,
              posted: false,
              attachmentUploaded: false,
              regularized: false,
              measurementApproved: false,
              measured: false,
              priorityAlert: false,
            };
            
            const invoiceResponse = await fetch('/api/invoices', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(invoiceData),
            });
            
            if (invoiceResponse.ok) {
              queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
              queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
              
              toast({
                title: "Nota fiscal criada automaticamente",
                description: `Nota ${xmlData.invoiceNumber} foi registrada no sistema.`,
              });
              
              // Fechar modal após criar automaticamente
              onClose();
              return;
            }
          }
        } catch (error) {
          console.error('Erro ao criar nota automaticamente:', error);
        }
      }
      
      toast({
        title: "Sucesso",
        description: `XML processado! Dados da nota fiscal ${xmlData.invoiceNumber} carregados.`,
      });

    } catch (error) {
      toast({
        title: "Erro ao processar XML",
        description: "Não foi possível extrair os dados do arquivo XML. Verifique se é um arquivo de NFe válido.",
        variant: "destructive",
      });
      console.error('Erro ao processar XML:', error);
    } finally {
      setIsProcessingXML(false);
      // Limpar o input para permitir upload do mesmo arquivo novamente
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const triggerXMLUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-invoice-form">
        <DialogHeader>
          <DialogTitle>
            {invoice ? "Editar Nota Fiscal" : "Nova Nota Fiscal"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            {/* Input Methods - Only for new invoices */}
            {!invoice && (
              <div className="space-y-4">
                <h4 className="font-medium text-foreground">Método de Entrada</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".xml"
                      onChange={handleXMLUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      data-testid="input-xml-file"
                    />
                    <button 
                      type="button" 
                      onClick={triggerXMLUpload}
                      disabled={isProcessingXML}
                      className="w-full p-4 border-2 border-dashed border-border rounded-lg text-center hover:border-primary hover:bg-primary/5 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      data-testid="button-upload-xml"
                    >
                      {isProcessingXML ? (
                        <>
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto mb-2"></div>
                          <div className="text-sm font-medium">Processando XML...</div>
                          <div className="text-xs text-muted-foreground">Extraindo dados da nota fiscal</div>
                        </>
                      ) : (
                        <>
                          <i className="fas fa-file-upload text-2xl text-muted-foreground mb-2"></i>
                          <div className="text-sm font-medium">Upload XML</div>
                          <div className="text-xs text-muted-foreground">Clique para selecionar arquivo XML</div>
                        </>
                      )}
                    </button>
                  </div>
                  
                  <button 
                    type="button" 
                    className="p-4 border-2 border-dashed border-border rounded-lg text-center hover:border-primary hover:bg-primary/5 transition-colors"
                    data-testid="button-barcode-scan"
                  >
                    <i className="fas fa-qrcode text-2xl text-muted-foreground mb-2"></i>
                    <div className="text-sm font-medium">Código de Barras</div>
                    <div className="text-xs text-muted-foreground">Escaneie o código</div>
                  </button>
                  
                  <div className="p-4 border-2 border-primary bg-primary/5 rounded-lg text-center">
                    <i className="fas fa-keyboard text-2xl text-primary mb-2"></i>
                    <div className="text-sm font-medium text-primary">Entrada Manual</div>
                    <div className="text-xs text-muted-foreground">Preencha manualmente</div>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="invoiceNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Número da Nota *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Ex: NFE-2024-001" 
                          data-testid="input-invoice-number"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="supplierId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fornecedor *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-supplier">
                            <SelectValue placeholder="Selecione um fornecedor" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {suppliers.map((supplier) => (
                            <SelectItem key={supplier.id} value={supplier.id}>
                              {supplier.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="invoiceType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tipo de Nota *</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-invoice-type">
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="contract">Contrato</SelectItem>
                          <SelectItem value="adhoc">Avulsa</SelectItem>
                          <SelectItem value="rental">Locação</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="value"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Valor *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="0,00" 
                          data-testid="input-value"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data de Emissão *</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          data-testid="input-issue-date"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data de Vencimento *</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          data-testid="input-due-date"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contractBalance"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Saldo do Contrato</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="0,00" 
                          data-testid="input-contract-balance"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Status Checkboxes */}
                <div className="space-y-3">
                  <FormLabel>Status da Nota</FormLabel>
                  
                  <FormField
                    control={form.control}
                    name="posted"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-posted"
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Nota Lançada
                        </FormLabel>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="attachmentUploaded"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-attachment"
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Boleto Anexo
                        </FormLabel>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="regularized"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-regularized"
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Regularização
                        </FormLabel>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="measurementApproved"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-measurement-approved"
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Aprovação da Medição
                        </FormLabel>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="measured"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-measured"
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Medido
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-border">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                data-testid="button-cancel"
              >
                Cancelar
              </Button>
              <Button 
                type="submit"
                data-testid="button-save"
              >
                <i className="fas fa-save mr-2"></i>
                Salvar Nota
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
