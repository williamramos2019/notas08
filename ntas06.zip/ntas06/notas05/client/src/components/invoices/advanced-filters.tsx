import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import type { Supplier } from "@shared/schema";

export interface FilterOptions {
  startDate?: string;
  endDate?: string;
  supplierId?: string;
  invoiceType?: string;
  minValue?: number;
  maxValue?: number;
  posted?: boolean;
  attachmentUploaded?: boolean;
  regularized?: boolean;
  measurementApproved?: boolean;
  measured?: boolean;
  overdue?: boolean;
}

interface AdvancedFiltersProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  suppliers: Supplier[];
  onClearFilters: () => void;
}

export function AdvancedFilters({ filters, onFiltersChange, suppliers, onClearFilters }: AdvancedFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleFilterChange = (key: keyof FilterOptions, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value === "" ? undefined : value
    });
  };

  const getActiveFiltersCount = () => {
    return Object.values(filters).filter(value => value !== undefined && value !== "").length;
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="relative">
          <i className="fas fa-filter mr-2"></i>
          Filtros Avançados
          {getActiveFiltersCount() > 0 && (
            <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {getActiveFiltersCount()}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-96 max-h-[80vh] overflow-y-auto" align="start">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium">Filtros Avançados</h4>
            <Button variant="ghost" size="sm" onClick={onClearFilters}>
              <i className="fas fa-times mr-1"></i>
              Limpar
            </Button>
          </div>

          <Separator />

          {/* Filtros de Data */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Período</Label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="start-date" className="text-xs">Data Inicial</Label>
                <Input
                  id="start-date"
                  type="date"
                  value={filters.startDate || ""}
                  onChange={(e) => handleFilterChange("startDate", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="end-date" className="text-xs">Data Final</Label>
                <Input
                  id="end-date"
                  type="date"
                  value={filters.endDate || ""}
                  onChange={(e) => handleFilterChange("endDate", e.target.value)}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Filtro de Fornecedor */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Fornecedor</Label>
            <Select
              value={filters.supplierId || ""}
              onValueChange={(value) => handleFilterChange("supplierId", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todos os fornecedores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Todos os fornecedores</SelectItem>
                {suppliers.map((supplier) => (
                  <SelectItem key={supplier.id} value={supplier.id}>
                    {supplier.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Filtro de Tipo */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Tipo de Nota</Label>
            <Select
              value={filters.invoiceType || ""}
              onValueChange={(value) => handleFilterChange("invoiceType", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todos os tipos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Todos os tipos</SelectItem>
                <SelectItem value="contract">Contrato</SelectItem>
                <SelectItem value="adhoc">Avulsa</SelectItem>
                <SelectItem value="rental">Locação</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Filtros de Valor */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Faixa de Valor</Label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="min-value" className="text-xs">Valor Mínimo</Label>
                <Input
                  id="min-value"
                  type="number"
                  placeholder="0,00"
                  step="0.01"
                  value={filters.minValue || ""}
                  onChange={(e) => handleFilterChange("minValue", e.target.value ? parseFloat(e.target.value) : undefined)}
                />
              </div>
              <div>
                <Label htmlFor="max-value" className="text-xs">Valor Máximo</Label>
                <Input
                  id="max-value"
                  type="number"
                  placeholder="0,00"
                  step="0.01"
                  value={filters.maxValue || ""}
                  onChange={(e) => handleFilterChange("maxValue", e.target.value ? parseFloat(e.target.value) : undefined)}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Filtros de Status */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Status</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="posted"
                  checked={filters.posted === true}
                  onCheckedChange={(checked) => 
                    handleFilterChange("posted", checked === true ? true : undefined)
                  }
                />
                <Label htmlFor="posted" className="text-sm">Apenas Lançadas</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="attachment"
                  checked={filters.attachmentUploaded === true}
                  onCheckedChange={(checked) => 
                    handleFilterChange("attachmentUploaded", checked === true ? true : undefined)
                  }
                />
                <Label htmlFor="attachment" className="text-sm">Anexo Carregado</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="regularized"
                  checked={filters.regularized === true}
                  onCheckedChange={(checked) => 
                    handleFilterChange("regularized", checked === true ? true : undefined)
                  }
                />
                <Label htmlFor="regularized" className="text-sm">Regularizada</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="measurement-approved"
                  checked={filters.measurementApproved === true}
                  onCheckedChange={(checked) => 
                    handleFilterChange("measurementApproved", checked === true ? true : undefined)
                  }
                />
                <Label htmlFor="measurement-approved" className="text-sm">Medição Aprovada</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="measured"
                  checked={filters.measured === true}
                  onCheckedChange={(checked) => 
                    handleFilterChange("measured", checked === true ? true : undefined)
                  }
                />
                <Label htmlFor="measured" className="text-sm">Medida</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="overdue"
                  checked={filters.overdue === true}
                  onCheckedChange={(checked) => 
                    handleFilterChange("overdue", checked === true ? true : undefined)
                  }
                />
                <Label htmlFor="overdue" className="text-sm text-red-600">Apenas Vencidas</Label>
              </div>
            </div>
          </div>

          <Separator />

          <div className="flex gap-2">
            <Button 
              onClick={() => setIsOpen(false)}
              className="flex-1"
            >
              <i className="fas fa-check mr-2"></i>
              Aplicar
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}