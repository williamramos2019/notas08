interface HeaderProps {
  title: string;
  subtitle: string;
  onAddClick?: () => void;
  addButtonText?: string;
}

export function Header({ title, subtitle, onAddClick, addButtonText = "Nova Nota" }: HeaderProps) {
  return (
    <header className="bg-card border-b border-border p-4 flex items-center justify-between shadow-sm">
      <div>
        <h2 className="text-2xl font-bold text-foreground">{title}</h2>
        <p className="text-muted-foreground">{subtitle}</p>
      </div>
      
      <div className="flex items-center gap-4">
        {onAddClick && (
          <button
            onClick={onAddClick}
            data-testid="button-add-new"
            className="bg-primary text-primary-foreground px-4 py-2 rounded-md font-medium hover:bg-primary/90 transition-colors flex items-center gap-2"
          >
            <i className="fas fa-plus"></i>
            {addButtonText}
          </button>
        )}
        
        <div className="relative">
          <button 
            data-testid="button-notifications"
            className="w-10 h-10 bg-accent rounded-full flex items-center justify-center text-accent-foreground hover:bg-accent/80 transition-colors relative"
          >
            <i className="fas fa-bell"></i>
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
              3
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
