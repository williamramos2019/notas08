import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigation = [
  { name: 'Dashboard', href: '/', icon: 'fas fa-tachometer-alt' },
  { name: 'Notas Fiscais', href: '/invoices', icon: 'fas fa-file-invoice' },
  { name: 'Fornecedores', href: '/suppliers', icon: 'fas fa-building' },
  { name: 'Relatórios', href: '/reports', icon: 'fas fa-chart-bar' },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col shadow-sm">
      <div className="p-6 border-b border-border">
        <h1 className="text-xl font-bold text-primary flex items-center gap-2">
          <i className="fas fa-file-invoice-dollar"></i>
          Controle NF
        </h1>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              data-testid={`nav-${item.name.toLowerCase().replace(' ', '-')}`}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md font-medium transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
            >
              <i className={item.icon}></i>
              {item.name}
            </Link>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-3 text-sm text-muted-foreground">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-semibold">
            <span>UA</span>
          </div>
          <div>
            <div className="font-medium text-foreground">Usuário Admin</div>
            <div className="text-xs">Administrador</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
