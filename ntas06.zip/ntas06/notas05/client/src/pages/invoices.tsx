import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { InvoiceTable } from "@/components/invoices/invoice-table";
import { InvoiceFormModal } from "@/components/invoices/invoice-form-modal";
import { AdvancedFilters, type FilterOptions } from "@/components/invoices/advanced-filters";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { InvoiceWithSupplier, InsertInvoice } from "@shared/schema";
import type { InvoiceFormData } from "@/lib/types";

export default function Invoices() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<InvoiceWithSupplier | undefined>();
  const [showPendingOnly, setShowPendingOnly] = useState(false);
  const [deletingInvoice, setDeletingInvoice] = useState<InvoiceWithSupplier | undefined>();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState<FilterOptions>({});

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ["/api/invoices"],
    queryFn: api.getInvoices,
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["/api/suppliers"],
    queryFn: api.getSuppliers,
  });

  const createInvoiceMutation = useMutation({
    mutationFn: (data: InsertInvoice) => api.createInvoice(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      setShowAddModal(false);
      toast({
        title: "Sucesso",
        description: "Nota fiscal criada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao criar nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertInvoice> }) =>
      api.updateInvoice(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      setShowAddModal(false);
      toast({
        title: "Sucesso",
        description: "Nota fiscal atualizada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao atualizar nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const deleteInvoiceMutation = useMutation({
    mutationFn: (id: string) => api.deleteInvoice(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      setShowDeleteDialog(false);
      setDeletingInvoice(undefined);
      toast({
        title: "Sucesso",
        description: "Nota fiscal excluída com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao excluir nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleAddInvoice = () => {
    setEditingInvoice(undefined);
    setShowAddModal(true);
  };

  const handleEditInvoice = (invoice: InvoiceWithSupplier) => {
    setEditingInvoice(invoice);
    setShowAddModal(true);
  };

  const handleViewInvoice = (invoice: InvoiceWithSupplier) => {
    console.log("View invoice:", invoice);
  };

  const handleDeleteInvoice = (invoice: InvoiceWithSupplier) => {
    setDeletingInvoice(invoice);
    setShowDeleteDialog(true);
  };

  const confirmDeleteInvoice = () => {
    if (deletingInvoice) {
      deleteInvoiceMutation.mutate(deletingInvoice.id);
    }
  };

  const handleAdvancedFiltersChange = (filters: FilterOptions) => {
    setAdvancedFilters(filters);
  };

  const clearAdvancedFilters = () => {
    setAdvancedFilters({});
  };

  const handleSubmitInvoice = (data: InvoiceFormData) => {
    const invoiceData: InsertInvoice = {
      invoiceNumber: data.invoiceNumber,
      supplierId: data.supplierId,
      issueDate: new Date(data.issueDate),
      dueDate: new Date(data.dueDate),
      value: parseFloat(data.value.replace(/[^\d,]/g, '').replace(',', '.')),
      invoiceType: data.invoiceType,
      posted: data.posted,
      attachmentUploaded: data.attachmentUploaded,
      regularized: data.regularized,
      measurementApproved: data.measurementApproved,
      measured: data.measured,
      contractBalance: data.contractBalance ? parseFloat(data.contractBalance.replace(/[^\d,]/g, '').replace(',', '.')) : undefined,
      priorityAlert: false,
    };

    if (editingInvoice) {
      updateInvoiceMutation.mutate({ id: editingInvoice.id, data: invoiceData });
    } else {
      createInvoiceMutation.mutate(invoiceData);
    }
  };

  // Aplicar filtros avançados
  const filteredInvoices = useMemo(() => {
    let filtered = [...invoices];

    // Filtro por notas pendentes (legado)
    if (showPendingOnly) {
      filtered = filtered.filter(invoice => !invoice.posted);
    }

    // Filtros avançados
    if (advancedFilters.startDate) {
      filtered = filtered.filter(invoice => 
        new Date(invoice.issueDate) >= new Date(advancedFilters.startDate!)
      );
    }

    if (advancedFilters.endDate) {
      filtered = filtered.filter(invoice => 
        new Date(invoice.issueDate) <= new Date(advancedFilters.endDate!)
      );
    }

    if (advancedFilters.supplierId) {
      filtered = filtered.filter(invoice => 
        invoice.supplierId === advancedFilters.supplierId
      );
    }

    if (advancedFilters.invoiceType) {
      filtered = filtered.filter(invoice => 
        invoice.invoiceType === advancedFilters.invoiceType
      );
    }

    if (advancedFilters.minValue !== undefined) {
      filtered = filtered.filter(invoice => 
        invoice.value >= advancedFilters.minValue!
      );
    }

    if (advancedFilters.maxValue !== undefined) {
      filtered = filtered.filter(invoice => 
        invoice.value <= advancedFilters.maxValue!
      );
    }

    if (advancedFilters.posted === true) {
      filtered = filtered.filter(invoice => invoice.posted === true);
    }

    if (advancedFilters.attachmentUploaded === true) {
      filtered = filtered.filter(invoice => invoice.attachmentUploaded === true);
    }

    if (advancedFilters.regularized === true) {
      filtered = filtered.filter(invoice => invoice.regularized === true);
    }

    if (advancedFilters.measurementApproved === true) {
      filtered = filtered.filter(invoice => invoice.measurementApproved === true);
    }

    if (advancedFilters.measured === true) {
      filtered = filtered.filter(invoice => invoice.measured === true);
    }

    if (advancedFilters.overdue === true) {
      filtered = filtered.filter(invoice => {
        const dueDate = new Date(invoice.dueDate);
        const now = new Date();
        return dueDate < now;
      });
    }

    return filtered;
  }, [invoices, showPendingOnly, advancedFilters]);

  // Função para exportar para CSV
  const exportInvoicesToCSV = (invoicesToExport: typeof invoices) => {
    const csvHeader = [
      'Número da Nota',
      'Fornecedor',
      'CNPJ',
      'Tipo',
      'Data Emissão',
      'Data Vencimento',
      'Valor',
      'Nota Lançada',
      'Boleto Anexo',
      'Regularização',
      'Aprovação Medição',
      'Medido',
      'Status Geral'
    ].join(',');

    const csvRows = invoicesToExport.map(invoice => {
      const getStatusText = () => {
        if (invoice.posted && invoice.attachmentUploaded && invoice.regularized && invoice.measurementApproved && invoice.measured) {
          return 'Completo';
        } else if (!invoice.posted) {
          return 'Pendente Lançamento';
        } else {
          return 'Em Processamento';
        }
      };

      return [
        invoice.invoiceNumber,
        `"${invoice.supplier.name}"`,
        invoice.supplier.cnpj,
        invoice.invoiceType === 'contract' ? 'Contrato' : invoice.invoiceType === 'rental' ? 'Locação' : 'Avulsa',
        new Date(invoice.issueDate).toLocaleDateString('pt-BR'),
        new Date(invoice.dueDate).toLocaleDateString('pt-BR'),
        `"R$ ${invoice.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}"`,
        invoice.posted ? 'Sim' : 'Não',
        invoice.attachmentUploaded ? 'Sim' : 'Não',
        invoice.regularized ? 'Sim' : 'Não',
        invoice.measurementApproved ? 'Sim' : 'Não',
        invoice.measured ? 'Sim' : 'Não',
        getStatusText()
      ].join(',');
    });

    const csvContent = [csvHeader, ...csvRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `notas-fiscais-${showPendingOnly ? 'pendentes-' : ''}${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Exportação concluída",
      description: `${invoicesToExport.length} nota(s) exportada(s) para CSV`,
    });
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Notas Fiscais"
        subtitle="Gerenciamento de notas fiscais"
        onAddClick={handleAddInvoice}
        addButtonText="Nova Nota"
      />

      <div className="flex-1 overflow-auto p-6">
        {/* Filtro para notas pendentes */}
        <div className="mb-6 bg-card border border-border rounded-lg p-4">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="pending-filter"
                  checked={showPendingOnly}
                  onCheckedChange={(checked) => setShowPendingOnly(checked === true)}
                  data-testid="checkbox-pending-filter"
                />
                <label 
                  htmlFor="pending-filter" 
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                >
                  <i className="fas fa-exclamation-circle text-yellow-500 mr-2"></i>
                  Mostrar apenas Notas Pendentes de Lançamento
                </label>
              </div>

              <AdvancedFilters
                filters={advancedFilters}
                onFiltersChange={handleAdvancedFiltersChange}
                suppliers={suppliers}
                onClearFilters={clearAdvancedFilters}
              />
            </div>
            
            {/* Botão de exportação */}
            <button
              onClick={() => exportInvoicesToCSV(filteredInvoices)}
              className="inline-flex items-center px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground border border-border rounded-md hover:bg-accent transition-colors"
              title="Exportar lista para CSV"
            >
              <i className="fas fa-download mr-2"></i>
              Exportar CSV
            </button>
          </div>
          
          {showPendingOnly && (
            <p className="text-xs text-muted-foreground mt-2">
              Mostrando {filteredInvoices.length} nota(s) pendente(s) de lançamento
            </p>
          )}
        </div>

        {isLoading ? (
          <div className="bg-card border border-border rounded-lg p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando notas fiscais...</p>
          </div>
        ) : (
          <InvoiceTable
            invoices={filteredInvoices}
            onEdit={handleEditInvoice}
            onView={handleViewInvoice}
            onDelete={handleDeleteInvoice}
          />
        )}
      </div>

      <InvoiceFormModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={handleSubmitInvoice}
        invoice={editingInvoice}
      />

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a nota fiscal {deletingInvoice?.invoiceNumber}?
              <br />
              <strong>Esta ação não pode ser desfeita.</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteInvoice}
              className="bg-red-600 hover:bg-red-700"
            >
              <i className="fas fa-trash mr-2"></i>
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
