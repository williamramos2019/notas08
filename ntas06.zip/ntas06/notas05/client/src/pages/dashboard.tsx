import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { MetricsCard } from "@/components/ui/metrics-card";
import { InvoiceTable } from "@/components/invoices/invoice-table";
import { InvoiceFormModal } from "@/components/invoices/invoice-form-modal";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { InvoiceWithSupplier, InsertInvoice } from "@shared/schema";
import type { InvoiceFormData, InvoiceFilter } from "@/lib/types";

export default function Dashboard() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<InvoiceWithSupplier | undefined>();
  const [deletingInvoice, setDeletingInvoice] = useState<InvoiceWithSupplier | undefined>();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [filters, setFilters] = useState<InvoiceFilter>({
    search: "",
    type: "",
    status: "",
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Queries
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    queryFn: api.getDashboardMetrics,
  });

  const { data: invoices = [], isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/invoices"],
    queryFn: api.getInvoices,
  });

  // Mutations
  const createInvoiceMutation = useMutation({
    mutationFn: (data: InsertInvoice) => api.createInvoice(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      toast({
        title: "Sucesso",
        description: "Nota fiscal criada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao criar nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const updateInvoiceMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertInvoice> }) =>
      api.updateInvoice(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      toast({
        title: "Sucesso",
        description: "Nota fiscal atualizada com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao atualizar nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const deleteInvoiceMutation = useMutation({
    mutationFn: (id: string) => api.deleteInvoice(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      setShowDeleteDialog(false);
      setDeletingInvoice(undefined);
      toast({
        title: "Sucesso",
        description: "Nota fiscal excluída com sucesso!",
      });
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Erro ao excluir nota fiscal. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  // Event handlers
  const handleAddInvoice = () => {
    setEditingInvoice(undefined);
    setShowAddModal(true);
  };

  const handleEditInvoice = (invoice: InvoiceWithSupplier) => {
    setEditingInvoice(invoice);
    setShowAddModal(true);
  };

  const handleViewInvoice = (invoice: InvoiceWithSupplier) => {
    // TODO: Implement view modal or navigate to detail page
    console.log("View invoice:", invoice);
  };

  const handleDeleteInvoice = (invoice: InvoiceWithSupplier) => {
    setDeletingInvoice(invoice);
    setShowDeleteDialog(true);
  };

  const confirmDeleteInvoice = () => {
    if (deletingInvoice) {
      deleteInvoiceMutation.mutate(deletingInvoice.id);
    }
  };

  const handleSubmitInvoice = (data: InvoiceFormData) => {
    const invoiceData: InsertInvoice = {
      invoiceNumber: data.invoiceNumber,
      supplierId: data.supplierId,
      issueDate: new Date(data.issueDate),
      dueDate: new Date(data.dueDate),
      value: parseFloat(data.value.replace(/[^\d,]/g, '').replace(',', '.')),
      invoiceType: data.invoiceType,
      posted: data.posted,
      attachmentUploaded: data.attachmentUploaded,
      regularized: data.regularized,
      measurementApproved: data.measurementApproved,
      measured: data.measured,
      contractBalance: data.contractBalance ? parseFloat(data.contractBalance.replace(/[^\d,]/g, '').replace(',', '.')) : undefined,
      priorityAlert: false,
    };

    if (editingInvoice) {
      updateInvoiceMutation.mutate({ id: editingInvoice.id, data: invoiceData });
    } else {
      createInvoiceMutation.mutate(invoiceData);
    }
  };

  // Filter invoices
  const filteredInvoices = invoices.filter((invoice) => {
    const searchMatch = !filters.search || 
      invoice.invoiceNumber.toLowerCase().includes(filters.search.toLowerCase()) ||
      invoice.supplier.name.toLowerCase().includes(filters.search.toLowerCase());
    
    const typeMatch = !filters.type || filters.type === 'all' || invoice.invoiceType === filters.type;
    
    const statusMatch = !filters.status || filters.status === 'all' || 
      (filters.status === 'pending' && (!invoice.posted || !invoice.attachmentUploaded || !invoice.regularized)) ||
      (filters.status === 'approved' && invoice.posted && invoice.attachmentUploaded && invoice.regularized) ||
      (filters.status === 'overdue' && new Date(invoice.dueDate) < new Date());

    return searchMatch && typeMatch && statusMatch;
  });

  const formatCurrency = (value: string) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(parseFloat(value));
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Dashboard de Alertas"
        subtitle="Controle e monitoramento de notas fiscais"
        onAddClick={handleAddInvoice}
        addButtonText="Nova Nota"
      />

      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricsCard
            title="Total de Notas"
            value={metricsLoading ? "..." : metrics?.totalInvoices || 0}
            icon="fas fa-file-invoice"
            iconColor="bg-blue-100"
            change="+12%"
            changeLabel="este mês"
          />
          <MetricsCard
            title="Pendentes"
            value={metricsLoading ? "..." : metrics?.pendingInvoices || 0}
            icon="fas fa-clock"
            iconColor="bg-yellow-100"
            change="8 urgentes"
            changeColor="text-yellow-600"
          />
          <MetricsCard
            title="Vencendo"
            value={metricsLoading ? "..." : metrics?.dueSoonInvoices || 0}
            icon="fas fa-exclamation-triangle"
            iconColor="bg-red-100"
            change="≤ 5 dias"
            changeColor="text-red-600"
          />
          <MetricsCard
            title="Valor Total"
            value={metricsLoading ? "..." : metrics ? formatCurrency(metrics.totalValue) : "R$ 0"}
            icon="fas fa-money-bill-wave"
            iconColor="bg-green-100"
            change="+5.2%"
            changeLabel="este mês"
          />
        </div>

        {/* Filters and Search */}
        <div className="bg-card border border-border rounded-lg p-6 shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
                <Input
                  placeholder="Buscar por número, fornecedor..."
                  className="pl-10 w-full sm:w-80"
                  value={filters.search}
                  onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                  data-testid="input-search"
                />
              </div>

              <Select value={filters.type} onValueChange={(value) => setFilters({ ...filters, type: value })}>
                <SelectTrigger className="w-[180px]" data-testid="select-filter-type">
                  <SelectValue placeholder="Todos os tipos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os tipos</SelectItem>
                  <SelectItem value="contract">Contrato</SelectItem>
                  <SelectItem value="adhoc">Avulsa</SelectItem>
                  <SelectItem value="rental">Locação</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                <SelectTrigger className="w-[180px]" data-testid="select-filter-status">
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="pending">Pendente</SelectItem>
                  <SelectItem value="approved">Aprovado</SelectItem>
                  <SelectItem value="overdue">Vencido</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" data-testid="button-advanced-filters">
                <i className="fas fa-filter mr-2"></i>
                Filtros Avançados
              </Button>
              <Button variant="outline" data-testid="button-export">
                <i className="fas fa-download mr-2"></i>
                Exportar
              </Button>
            </div>
          </div>
        </div>

        {/* Invoices Table */}
        {invoicesLoading ? (
          <div className="bg-card border border-border rounded-lg p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando notas fiscais...</p>
          </div>
        ) : (
          <InvoiceTable
            invoices={filteredInvoices}
            onEdit={handleEditInvoice}
            onView={handleViewInvoice}
            onDelete={handleDeleteInvoice}
          />
        )}
      </div>

      {/* Invoice Form Modal */}
      <InvoiceFormModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={handleSubmitInvoice}
        invoice={editingInvoice}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a nota fiscal "{deletingInvoice?.invoiceNumber}" do fornecedor "{deletingInvoice?.supplier?.name}"?
              <br />
              <strong>Esta ação não pode ser desfeita.</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteInvoice}
              className="bg-red-600 hover:bg-red-700"
            >
              <i className="fas fa-trash mr-2"></i>
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
