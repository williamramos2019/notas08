import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/layout/header";
import { MetricsCard } from "@/components/ui/metrics-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { InvoiceWithSupplier } from "@shared/schema";

export default function Reports() {
  const [reportPeriod, setReportPeriod] = useState("month");
  const [selectedSupplier, setSelectedSupplier] = useState("all");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const { toast } = useToast();

  // Fetch data
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    queryFn: api.getDashboardMetrics,
  });

  const { data: invoices = [], isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/invoices"],
    queryFn: api.getInvoices,
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["/api/suppliers"],
    queryFn: api.getSuppliers,
  });

  // Calculate report metrics
  const calculateMetrics = () => {
    let filteredInvoices = [...invoices];

    // Filter by date range if specified
    if (startDate) {
      filteredInvoices = filteredInvoices.filter(invoice => 
        new Date(invoice.issueDate) >= new Date(startDate)
      );
    }
    if (endDate) {
      filteredInvoices = filteredInvoices.filter(invoice => 
        new Date(invoice.issueDate) <= new Date(endDate)
      );
    }

    // Filter by supplier if specified
    if (selectedSupplier !== "all") {
      filteredInvoices = filteredInvoices.filter(invoice => 
        invoice.supplierId === selectedSupplier
      );
    }

    // Filter by period
    const now = new Date();
    const periodStart = new Date();
    
    switch (reportPeriod) {
      case "week":
        periodStart.setDate(now.getDate() - 7);
        break;
      case "month":
        periodStart.setMonth(now.getMonth() - 1);
        break;
      case "quarter":
        periodStart.setMonth(now.getMonth() - 3);
        break;
      case "year":
        periodStart.setFullYear(now.getFullYear() - 1);
        break;
    }

    if (reportPeriod !== "custom" && !startDate && !endDate) {
      filteredInvoices = filteredInvoices.filter(invoice => 
        new Date(invoice.issueDate) >= periodStart
      );
    }

    const totalValue = filteredInvoices.reduce((sum, invoice) => sum + invoice.value, 0);
    const averageValue = filteredInvoices.length > 0 ? totalValue / filteredInvoices.length : 0;
    const postedInvoices = filteredInvoices.filter(invoice => invoice.posted).length;
    const overdueInvoices = filteredInvoices.filter(invoice => {
      const dueDate = new Date(invoice.dueDate);
      return dueDate < now && !invoice.posted;
    }).length;

    return {
      total: filteredInvoices.length,
      totalValue,
      averageValue,
      postedCount: postedInvoices,
      overdueCount: overdueInvoices,
      postedPercentage: filteredInvoices.length > 0 ? (postedInvoices / filteredInvoices.length) * 100 : 0,
      filteredInvoices
    };
  };

  const reportMetrics = calculateMetrics();

  // Export functions
  const exportToCSV = () => {
    const { filteredInvoices } = reportMetrics;
    
    const csvHeader = [
      "Número",
      "Fornecedor",
      "Tipo",
      "Data de Emissão",
      "Data de Vencimento",
      "Valor",
      "Lançado",
      "Status"
    ].join(',');

    const csvRows = filteredInvoices.map(invoice => {
      const supplier = suppliers.find(s => s.id === invoice.supplierId);
      const getTypeLabel = (type: string) => {
        switch (type) {
          case 'contract': return 'Contrato';
          case 'adhoc': return 'Avulsa';
          case 'rental': return 'Locação';
          default: return type;
        }
      };

      const getStatus = () => {
        if (invoice.measured) return 'Medida';
        if (invoice.measurementApproved) return 'Medição Aprovada';
        if (invoice.regularized) return 'Regularizada';
        if (invoice.attachmentUploaded) return 'Anexo Carregado';
        if (invoice.posted) return 'Lançada';
        return 'Pendente';
      };

      return [
        invoice.invoiceNumber,
        `"${supplier?.name || 'N/A'}"`,
        getTypeLabel(invoice.invoiceType),
        new Date(invoice.issueDate).toLocaleDateString('pt-BR'),
        new Date(invoice.dueDate).toLocaleDateString('pt-BR'),
        `"R$ ${invoice.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}"`,
        invoice.posted ? 'Sim' : 'Não',
        getStatus()
      ].join(',');
    });

    const csvContent = [csvHeader, ...csvRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `relatorio-notas-fiscais-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Relatório exportado",
      description: `Relatório com ${filteredInvoices.length} notas exportado para CSV`,
    });
  };

  const formatCurrency = (value: number) => 
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);

  const formatPercentage = (value: number) => 
    `${value.toFixed(1)}%`;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <Header
        title="Relatórios"
        subtitle="Análise e relatórios de notas fiscais"
      />

      <div className="flex-1 overflow-auto p-6">
        {/* Filtros de Relatório */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-filter mr-2 text-primary"></i>
              Filtros do Relatório
            </CardTitle>
            <CardDescription>
              Configure os parâmetros para gerar o relatório personalizado
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="period">Período</Label>
                <Select value={reportPeriod} onValueChange={setReportPeriod}>
                  <SelectTrigger id="period">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="week">Última Semana</SelectItem>
                    <SelectItem value="month">Último Mês</SelectItem>
                    <SelectItem value="quarter">Último Trimestre</SelectItem>
                    <SelectItem value="year">Último Ano</SelectItem>
                    <SelectItem value="custom">Período Personalizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="supplier">Fornecedor</Label>
                <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
                  <SelectTrigger id="supplier">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os Fornecedores</SelectItem>
                    {suppliers.map((supplier) => (
                      <SelectItem key={supplier.id} value={supplier.id}>
                        {supplier.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {reportPeriod === "custom" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="start-date">Data Inicial</Label>
                    <Input
                      id="start-date"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end-date">Data Final</Label>
                    <Input
                      id="end-date"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </>
              )}
            </div>

            <div className="flex gap-2 mt-4">
              <Button onClick={exportToCSV}>
                <i className="fas fa-download mr-2"></i>
                Exportar CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Métricas do Relatório */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <MetricsCard
            title="Total de Notas"
            value={reportMetrics.total.toString()}
            icon="fas fa-file-invoice"
            iconColor="bg-blue-100"
            change={`${formatPercentage(reportMetrics.postedPercentage)}`}
            changeLabel="processadas"
            changeColor={reportMetrics.postedPercentage > 80 ? "text-green-600" : "text-yellow-600"}
          />
          <MetricsCard
            title="Valor Total"
            value={formatCurrency(reportMetrics.totalValue)}
            icon="fas fa-money-bill-wave"
            iconColor="bg-green-100"
            change={formatCurrency(reportMetrics.averageValue)}
            changeLabel="valor médio"
          />
          <MetricsCard
            title="Lançadas"
            value={reportMetrics.postedCount.toString()}
            icon="fas fa-check-circle"
            iconColor="bg-emerald-100"
            change={`${formatPercentage(reportMetrics.postedPercentage)}`}
            changeLabel="do total"
            changeColor="text-emerald-600"
          />
          <MetricsCard
            title="Vencidas"
            value={reportMetrics.overdueCount.toString()}
            icon="fas fa-exclamation-triangle"
            iconColor="bg-red-100"
            change={reportMetrics.overdueCount > 0 ? "Atenção!" : "Nenhuma"}
            changeLabel="em atraso"
            changeColor={reportMetrics.overdueCount > 0 ? "text-red-600" : "text-green-600"}
          />
        </div>

        {/* Análises Adicionais */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Status das Notas */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-chart-pie mr-2 text-primary"></i>
                Status das Notas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { label: "Lançadas", count: reportMetrics.postedCount, color: "bg-green-500" },
                  { label: "Pendentes", count: reportMetrics.total - reportMetrics.postedCount, color: "bg-yellow-500" },
                  { label: "Vencidas", count: reportMetrics.overdueCount, color: "bg-red-500" }
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full ${item.color} mr-3`}></div>
                      <span>{item.label}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{item.count}</div>
                      <div className="text-sm text-muted-foreground">
                        {reportMetrics.total > 0 ? formatPercentage((item.count / reportMetrics.total) * 100) : "0%"}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Fornecedores */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-building mr-2 text-primary"></i>
                Top Fornecedores
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {suppliers.slice(0, 5).map((supplier) => {
                  const supplierInvoices = reportMetrics.filteredInvoices.filter(
                    invoice => invoice.supplierId === supplier.id
                  );
                  const supplierValue = supplierInvoices.reduce((sum, invoice) => sum + invoice.value, 0);
                  
                  if (supplierInvoices.length === 0) return null;
                  
                  return (
                    <div key={supplier.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                          <i className="fas fa-building text-primary text-sm"></i>
                        </div>
                        <div>
                          <div className="font-medium">{supplier.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {supplierInvoices.length} nota{supplierInvoices.length !== 1 ? 's' : ''}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{formatCurrency(supplierValue)}</div>
                        <div className="text-sm text-muted-foreground">
                          {reportMetrics.totalValue > 0 ? formatPercentage((supplierValue / reportMetrics.totalValue) * 100) : "0%"}
                        </div>
                      </div>
                    </div>
                  );
                }).filter(Boolean)}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}