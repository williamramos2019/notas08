# Overview

This is a comprehensive Invoice Control System ("Controle de Notas Fiscais") built with modern web technologies. The system manages invoice processing, supplier information, and provides real-time alerts and dashboard metrics for financial tracking and compliance management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Build Tool**: Vite for fast development and optimized production builds with hot module replacement
- **Styling**: Tailwind CSS with shadcn/ui component library providing a consistent design system
- **Routing**: Wouter for lightweight client-side routing without the overhead of React Router
- **State Management**: TanStack Query (React Query) for server state management, caching, and synchronization
- **Form Handling**: React Hook Form with Zod validation for robust form management and client-side validation
- **UI Components**: Comprehensive Radix UI primitive components through shadcn/ui for accessibility and consistency

## Backend Architecture
- **Development**: Node.js with Express.js framework for RESTful API endpoints during development
- **Production**: PHP 8+ backend for cPanel compatibility with SQLite database
- **Database**: SQLite for local file-based storage, with Drizzle ORM for type-safe database operations
- **API Design**: RESTful endpoints for suppliers, invoices, and dashboard metrics
- **Deployment**: Dual configuration supporting both development (Node.js) and production (PHP/cPanel) environments

## Database Schema
The system uses a well-structured relational schema with three main entities:
- **Suppliers**: Store company information (name, CNPJ), contract balances, supplier types, and monitoring preferences
- **Invoices**: Track invoice details, status checkboxes, financial data, and relationships to suppliers
- **Alerts**: Manage due date notifications and priority alerts linked to invoices

## Component Architecture
- **Layout Components**: Sidebar navigation with active state management and header with notification system
- **Page Components**: Dashboard, invoices, suppliers, and reports sections with dedicated routing
- **UI Components**: Comprehensive shadcn/ui component library including forms, tables, dialogs, and data display components
- **Form Components**: Modular forms for invoice and supplier data entry with real-time validation

## Key Features
- **Invoice Management**: Support for contract, adhoc, and rental invoice types with complete lifecycle tracking
- **Supplier Database**: CNPJ validation, contract balance tracking, supplier type classification, and monitoring flags
- **Status Tracking**: Checkbox-based system for invoice processing stages (posted, attachment, regularized, etc.)
- **Alert System**: Automated due date notifications and priority alerts for monitored suppliers
- **Dashboard Metrics**: Real-time statistics including total invoices, pending items, due soon alerts, and financial summaries

# External Dependencies

## Database Services
- **SQLite**: Local file-based database for both development and production environments
- **Drizzle ORM**: Type-safe database operations with schema management and migrations
- **Better SQLite3**: High-performance SQLite driver for Node.js development environment

## UI and Styling
- **Radix UI**: Comprehensive set of low-level UI primitives for accessibility and consistency
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **shadcn/ui**: Pre-built component library combining Radix UI with Tailwind styling
- **Font Awesome**: Icon library for consistent iconography throughout the application

## Development Tools
- **Vite**: Modern build tool with fast development server and optimized production builds
- **TypeScript**: Static type checking for enhanced developer experience and code reliability
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Schema validation for both client and server-side data validation
- **date-fns**: Modern date utility library with internationalization support

## Deployment Infrastructure
- **cPanel Compatibility**: Optimized for shared hosting environments with PHP backend
- **Apache Configuration**: .htaccess files for proper routing and API endpoint handling
- **Asset Optimization**: Production builds with code splitting and asset minification